class ModelServerRateLimitError(Exception):
    """
    Exception raised for rate limiting errors from the model server.
    """
