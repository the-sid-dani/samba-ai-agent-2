These files are for public table migrations when operating with multi tenancy.

If you are not a Onyx developer, you can ignore this directory entirely.
