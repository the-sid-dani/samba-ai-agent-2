This folder contains images needed by the Onyx Slack Bot. When possible, we use the images
within `web/public`, but sometimes those images do not work for the Slack Bot.
